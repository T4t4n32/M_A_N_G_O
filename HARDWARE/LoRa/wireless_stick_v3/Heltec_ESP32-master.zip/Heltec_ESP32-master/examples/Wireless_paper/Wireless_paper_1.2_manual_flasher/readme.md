Set the image resolution to 250*122(consistent with the settings in **image.h**) and convert it to XBM.

Open the XBM file with VSCode or Notepad, then copy the image code.<br>
<img src="img/01.jpg"/>

Paste the code into image.h.<br>
<img src="img/02.jpg"/>
